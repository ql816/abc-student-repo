# CAR RACING ON THE INTERNET

## Description
The Internet is just like a highway. You are moving almost every moment at a high speed. Have you ever thought of playing a car race game using your browser? Here is your chance! Download this extension [here](https://github.com/ql816/abc-student-repo/raw/master/projects/project-B/Car_Racing.zip) to enjoy an exciting car race game on the web. You can drive through the Internet.
<br>
1.	This extension will show you the speed you scroll the page, with a speed meter shown on the page. It is never right to speed in reality, but the Internet might be an excellent place for you to speed up!
<br>
2.	For each page you visit, there will be a match. In 15 seconds, please try to scroll as fast as you can. The points you earned on each game will be dependent on the maximum speed you have reached. Try to make as many points as you can. The points will remain even if you start a new match on another page. If you want to start a new season, terminate the browser entirely, and open it again. Your score will be 0 in a new season.
<br>
3.	You will need to avoid the obstacles (the links). Once your mouse is placed on the links, you will lose 2 points. The difficulty level of a match is determined by the density of links on the page. Links are hazardous sometimes!
<br>
4.	At the beginning of each new match, we will check your total points earned. If the number of the points you owned is smaller than 0, then, unfortunately, you cannot take part in the match. You will need to fuel your vehicle. Try to find some links with the word “fuel” in their titles. Put your cursor on it. Your vehicle will be fueled and ready for a new game shortly. If links are used properly, they can be beneficial!
<br>
## demo
![image](demo.gif)

## Technical Explanation
